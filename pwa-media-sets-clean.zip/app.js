
const recentEl = document.getElementById('recent-sets');
const form = document.getElementById('create-set-form');

async function fetchJSON(url, opts={}){
  const res = await fetch(url, opts);
  if(!res.ok){
    const t = await res.text().catch(()=>'');
    throw new Error(`${res.status} ${res.statusText} ${t}`.trim());
  }
  return res.json();
}

async function loadRecent(){
  if(!recentEl) return;
  const data = await fetchJSON('/api/sets');
  recentEl.innerHTML = '';
  data.sets.slice(0, 8).forEach(s => {
    const a = document.createElement('a');
    a.href = `/set.html?id=${encodeURIComponent(s.id)}`;
    a.className = 'set-card';
    a.innerHTML = `<h3>${s.title || 'ไม่มีชื่อชุด'}</h3>
      <div class="muted">${new Date(s.created_at).toLocaleString()}</div>
      <div class="muted">จำนวนรายการ: ${s.item_count}</div>
      <div class="permalink">${location.origin}/set.html?id=${s.id}</div>`;
    recentEl.appendChild(a);
  });
}
loadRecent();

if(form){
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try{
      const fd = new FormData(form);
      // ถ้าตั้ง ADMIN_TOKEN ไว้ ให้เพิ่ม header ด้านล่าง (ไม่แนะนำฝั่ง client ในเว็บสาธารณะ)
      // const headers = { 'x-admin-token': 'YOUR_TOKEN' };
      const resp = await fetchJSON('/api/sets', {method:'POST', body: fd /*, headers*/});
      location.href = `/set.html?id=${encodeURIComponent(resp.id)}`;
    }catch(err){
      alert('สร้างชุดไม่สำเร็จ: ' + err.message);
    }
  });
}
