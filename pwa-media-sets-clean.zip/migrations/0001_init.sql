
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS sets (
  id TEXT PRIMARY KEY,
  title TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS items (
  id TEXT PRIMARY KEY,
  set_id TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('text','image','video')),
  text_content TEXT,
  object_key TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (set_id) REFERENCES sets(id) ON DELETE CASCADE
);
