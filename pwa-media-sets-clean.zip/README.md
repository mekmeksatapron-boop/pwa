
# PWA Media Sets (Cloudflare Pages + Functions + D1 + R2)

เว็บแอพ PWA สำหรับเก็บ **ชุด (sets)** ของข้อความ / รูปภาพ / วิดีโอ
- แต่ละ "ชุด" มีหน้าเฉพาะของตัวเอง
- ใต้รายการแต่ละตัวมีปุ่ม **คัดลอก** (ข้อความ/รูป/วิดีโอ) และ **ดาวน์โหลด**
- ใช้ **Cloudflare Pages** + **Pages Functions** + **D1** (metadata) + **R2** (ไฟล์สื่อ)
- Functions เขียนด้วย **JS ล้วน** (ไม่มีไลบรารีภายนอก)

## Quick Start

1) สร้างทรัพยากรบน Cloudflare
   - D1 database: `pwa_db`
   - R2 bucket: `pwa-media-bucket`
2) Pages → Settings → Functions → Bindings
   - D1: **Name = DB**, Database = **pwa_db**
   - R2: **Name = MEDIA**, Bucket = **pwa-media-bucket**
3) (ครั้งแรก) รัน migrations
```bash
wrangler d1 migrations apply pwa_db
```
4) ดีพลอย
```bash
wrangler pages deploy . --project-name <YOUR_PAGES_PROJECT>
```
> หรือเชื่อม Git ให้ Pages build อัตโนมัติ (ไม่มี build command; output dir = `.`)

## API endpoints
- `GET  /api/sets` → รายชื่อชุด + จำนวนรายการ
- `POST /api/sets` → สร้างชุด (FormData: `title?`)
- `GET  /api/sets/:id` → อ่านชุด + รายการในชุด
- `POST /api/sets/:id/items` (multipart) → เพิ่ม item
  - ข้อความ: `type=text`, `text=<ข้อความ>`
  - สื่อ: `type=image|video`, `file=<binary>`
- `GET  /media/<object_key>` → เสิร์ฟไฟล์จาก R2 (cache 30 วัน)

### สิทธิ์เขียน (ตัวเลือก)
- ตั้ง Env Var: `ADMIN_TOKEN` (ไม่บังคับ)
- ถ้าตั้งค่าไว้ ทุก `POST` ต้องส่ง header `x-admin-token` ให้ตรงกัน

## Dev local
```bash
wrangler pages dev .
# http://localhost:8788/
```
